## Video Tutorials 
### Youtube 视频
* [PHP Academy](https://www.youtube.com/user/phpacademy)
* [The New Boston](https://www.youtube.com/user/thenewboston)
* [Sherif Ramadan](https://www.youtube.com/user/businessgeek)
* [Level Up Tuts](https://www.youtube.com/user/LevelUpTuts)

### 付费视频

* [Standards and Best practices](http://teamtreehouse.com/library/standards-and-best-practices)
* [PHP Training on Pluralsight](http://www.pluralsight.com/search/?searchTerm=php)
* [PHP Training on Lynda.com](http://www.lynda.com/search?q=php)
* [PHP Training on Tutsplus](http://code.tutsplus.com/categories/php/courses)
* [Laracasts](https://laracasts.com/)
