## PHP 官方 
* [PHP 官方网站](http://php.net/)
* [PHP 官方文档](http://php.net/docs.php)
