# Servers and Deployment 
PHP applications can be deployed and run on production web servers in a number of ways.
