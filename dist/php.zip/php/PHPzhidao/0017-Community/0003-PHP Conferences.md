## PHP Conferences 
The PHP community also hosts larger regional and national conferences in many countries around the world. Well-known
members of the PHP community usually speak at these larger events, so it's a great opportunity to learn directly from
industry leaders.

[Find a PHP Conference][php-conf]


[php-conf]: http://php.net/conferences/index.php
