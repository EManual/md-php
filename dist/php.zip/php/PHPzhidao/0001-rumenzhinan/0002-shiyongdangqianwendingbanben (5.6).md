## 使用当前稳定版本 (5.6) 
如果你刚开始学习PHP，请使用最新的稳定版本 [PHP 5.6][php-release]。PHP 近年来有了巨大的改进，增加了许多强大的 [新特性](#language_highlights)。虽然 5.2 和 5.6 之间增加的版本号似乎很小， 但它代表了 _重大的_ 改进。如果你想查找一个函数及其用法，可以去官方手册[php.net][php-docs]中查找。

[php-release]: http://php.net/downloads.php
[php-docs]: http://php.net/manual/
